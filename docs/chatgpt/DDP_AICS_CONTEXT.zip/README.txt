DDP ChatGPT Context Pack

1. Upload DDP_AICS_CONTEXT.md to ChatGPT (recommended), OR unzip and upload docs/.
2. Paste the ChatGPT Startup Prompt from AI_BOOTSTRAP.md.
3. Ask ChatGPT to read the pack and follow AI INITIALIZATION PROTOCOL.
